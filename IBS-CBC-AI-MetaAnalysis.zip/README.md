# AI-Augmented CBC Markers for IBS Diagnosis

## Data Availability
| File | Description |
|------|-------------|
| [Global Studies](/data/aggregated_meta_data.csv) | 110 studies (24,350 IBS patients) |
| [Yemen Cohort](/data/yemen_cohort_raw.csv) | 142 patients from conflict zone |

## How to Reproduce Results

### 1. Run Meta-Analysis
```bash
Rscript code/meta_analysis/random_effects_model.R
```

### 2. Train AI Model
```bash
python code/AI_model/train_xgboost.py
```

## Dependencies
- R Packages: `metafor`, `ggplot2`
- Python Packages: `pandas`, `xgboost`, `scikit-learn`, `joblib`

## Contact
Dr. Naif Taleb Ali: n.taleb@ust.edu  
Dr. Hana Ali: Hanaalimohsen@gmail.com

## Limitations
- Control group data not included in Yemeni cohort due to [reason]
- Model uses IBS presence/absence as binary target (1 = IBS, 0 = missing subtype)
